	<header class="main-header header-style-two">
        <div class="header-upper">
        	<div class="auto-container">
            	<div class="clearfix">
                	<div class="pull-left logo-outer">
                    	<div class="logo"><a href="index.php" style="text-decoration: none;"><h1 style="font-size: 36px;font-family: 'Roboto', sans-serif; color: #012f5d; ">GIRIRAJ GROUP</h1></a></div>
                    </div>
                    <!-- <div class="pull-right upper-right clearfix">
                        <div class="upper-column info-box">
                        	<div class="icon-box"><span class="flaticon-support"></span></div>
                            <ul>
                            	<li>(022) 260 012 97</li>
                                <li>(022) 260 564 57</li>
                            </ul>
                        </div>
                        <div class="upper-column info-box">
                        	<div class="icon-box"><span class="flaticon-location"></span></div>
                            <ul>
                            	<li>2 - BHAGYARATAN, 3RD ROAD,<br>Khar (West), Mumbai</li>
                            </ul>
                        </div>
                        <div class="upper-column info-box">
                        	<div class="icon-box"><span class="flaticon-e-mail-envelope"></span></div>
                            <ul>
                                <li>giriraj_sons@yahoo.com</li>
                            </ul>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        <div class="header-lower">
        	<div class="auto-container">
            	<div class="nav-outer clearfix">
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li><a href="index.php">HOME </a></li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li><a href="projects.php">Projects</a></li>
                                <!-- <li><a href="#">Companies</a></li> -->
                                <li><a href="clients.php">Clients</a></li>
                                <li><a href="contact-us.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <div class="sticky-header">
        	<div class="auto-container clearfix">
            	<div class="logo pull-left">
                	<a href="index.php" class="img-responsive" style="text-decoration: none;"><h2 style="font-size: 30px;font-family: 'Roboto', sans-serif; color: #012f5d; ">GIRIRAJ GROUP</h2></a>
                </div>
                <div class="right-col pull-right">
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li><a href="index.php" style="color: #012f5d;">HOME</a></li>
                                <li><a href="about-us.php" style="color: #012f5d;">About Us</a></li>
                                <li><a href="services.php" style="color: #012f5d;">Services</a></li>
                                <li><a href="projects.php" style="color: #012f5d;">Projects</a></li>
                                <!-- <li><a href="#">Companies</a></li> -->
                                <li><a href="clients.php" style="color: #012f5d;">Clients</a></li>
                                <li><a href="contact-us.php" style="color: #012f5d;">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>