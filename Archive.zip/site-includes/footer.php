    <footer class="main-footer footer-style-two">
        <div class="footer-bottom">
        	<div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-5 col-md-12 col-xs-12"><div class="copyright-text" style="text-align: center;">&copy; 2017 All Rights Reserved with &nbsp;<a href="http://kreaserv.com/"><img src="images/kreaserv.png" style="width: 20%; padding-bottom: 3px;"></a></div></div>
                    <div class="col-lg-7 col-md-12 col-xs-12">
                        <nav class="footer-nav clearfix">
                           <!--  <ul class="pull-right clearfix">
                                <li><a href="https://www.facebook.com/giriraj.sahani"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="https://in.linkedin.com/in/giriraj-sahani-8a1a2177"><span class="fa fa-linkedin"></span></a></li>
                                <li><a href="contact-us.php">contact us</a></li>
                            </ul> -->
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </footer>